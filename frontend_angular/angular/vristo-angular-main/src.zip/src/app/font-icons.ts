import { Component } from '@angular/core';

@Component({
    templateUrl: './font-icons.html',
})
export class FontIconsComponent {
    constructor() {}
}
